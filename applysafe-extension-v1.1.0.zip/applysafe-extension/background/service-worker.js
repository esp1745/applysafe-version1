/**
 * ApplySafe - Background Service Worker
 * Handles AI analysis, API calls, and extension coordination
 */

// Import modules
importScripts('database.js');
importScripts('subscription.js');
importScripts('auth.js');
importScripts('h1b.js');

// Configuration
const CONFIG = {
  BACKEND_URL: 'https://applysafe-version1.vercel.app',
  API_ENDPOINT: 'https://applysafe-version1.vercel.app/api/analyze-job',
  MODEL: 'claude-3-haiku-20240307', // Fast and cost-effective for this use case
  MAX_TOKENS: 1024,
  CACHE_DURATION: 3600000, // 1 hour in ms
  RATE_LIMIT_DELAY: 500, // 500ms between API calls (only for auto-analysis)
  API_TIMEOUT: 15000 // 15 second timeout (backend proxy needs more time)
};

// State
let lastApiCall = 0;

// Initialize extension
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    // Initialize subscription (start free trial)
    await initializeSubscription();
    
    // Set default settings
    await chrome.storage.local.set({
      settings: {
        autoAnalyze: true,
        showBadges: true,
        notifyHighRisk: true,
        apiKey: ''
      },
      stats: {
        scamsBlocked: 0,
        jobsScanned: 0,
        reportsSubmitted: 0
      },
      whitelist: [],
      recentScans: [],
      analysisCache: {},
      reports: []
    });
    
    // Open options page for API key setup
    chrome.runtime.openOptionsPage();
  } else if (details.reason === 'update') {
    // Clear old cache on extension update to refresh H1B data
    console.log('ApplySafe: Extension updated, clearing old caches');
    await chrome.storage.local.remove(['analysisCache', 'h1bCache']);
  }
});

// Listen for successful payment completion
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // Check if user landed on success page after payment
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('localhost:3000/success')) {
    console.log('Payment success page detected!');
    
    // Extract session_id from URL
    const urlParams = new URLSearchParams(new URL(tab.url).search);
    const sessionId = urlParams.get('session_id');
    
    if (sessionId) {
      console.log('Session ID found:', sessionId);
      
      // Wait a moment for Stripe to process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Retrieve session details from backend
      try {
        const response = await fetch(`http://localhost:3000/api/get-session?session_id=${sessionId}`);
        const data = await response.json();
        
        if (data.customerId) {
          console.log('Activating subscription with customer ID:', data.customerId);
          await activateSubscription(data.customerId, sessionId);
        }
      } catch (error) {
        console.error('Error retrieving session:', error);
      }
    }
  }
});

// Create context menu (do this on startup, not just on install)
try {
  chrome.contextMenus.create({
    id: 'analyzeJob',
    title: 'Analyze this job with ApplySafe',
    contexts: ['page', 'link']
  });
} catch (e) {
  // Menu might already exist
  console.log('Context menu setup:', e.message);
}

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  handleMessage(request, sender)
    .then(response => {
      sendResponse(response);
    })
    .catch(error => {
      console.error('Message handler error:', error);
      sendResponse({ success: false, error: error.message });
    });
  return true; // Keep channel open for async response
});

// Handle incoming messages
async function handleMessage(request, sender) {
  try {
    switch (request.action) {
      case 'analyzeJob':
        return await analyzeJob(request.jobData, request.url, request.autoAnalysis);
        
      case 'reportScam':
        return await reportScam(request.data);
        
      case 'jobDetected':
        // Log job detection for analytics
        console.log('Job detected:', request.jobData?.title);
        return { success: true };
        
      case 'openPopup':
        // Can't programmatically open popup, but can open options
        chrome.runtime.openOptionsPage();
        return { success: true };
        
      case 'getJobHistory':
        return { jobs: await getAllJobs(request.limit || 100) };
        
      case 'searchJobs':
        return { jobs: await searchJobs(request.query) };
        
      case 'getStats':
        return { stats: await getStats() };
        
      case 'addToWhitelist':
        await addToWhitelist(request.company, request.reason);
        return { success: true };
        
      case 'checkWhitelist':
        return { isWhitelisted: await isWhitelisted(request.company) };
        
      case 'getJobsByCompany':
        return { jobs: await getJobsByCompany(request.company) };
        
      case 'getSubscription':
        return { subscription: await getSubscriptionStatus() };
        
      case 'getTrialInfo':
        return { trialInfo: await getTrialInfo() };
        
      case 'startCheckout':
        return await createCheckoutSession();
        
      case 'validateLicense':
        return await validateLicenseKey(request.licenseKey);
        
      case 'cancelSubscription':
        return await cancelSubscription();
        
      case 'syncSubscription':
        await syncSubscriptionStatus();
        return { success: true };
        
      case 'activateSubscription':
        return await activateSubscription(request.customerId, request.sessionId);
        
      case 'getAuthStatus':
        return { authStatus: await auth.getAuthStatus() };
        
      case 'signInWithGoogle':
        return await auth.signInWithGoogle();
        
      case 'signOut':
        return await auth.signOut();
        
      case 'clearCache':
        await clearAllCache();
        return { success: true };
      
      // H1B Sponsorship Actions
      case 'checkH1BSponsorship':
        const h1bResult = await self.h1bModule.checkH1BSponsorship(request.companyName);
        return { success: true, h1bData: h1bResult };
        
      case 'submitH1BFeedback':
        return await self.h1bModule.submitH1BFeedback(
          request.companyName, 
          request.isAccurate, 
          request.comment
        );
        
      case 'getH1BFeedback':
        const feedback = await self.h1bModule.getH1BFeedback(request.companyName);
        return { success: true, feedback: feedback };
        
      default:
        return { error: 'Unknown action' };
    }
  } catch (error) {
    console.error('Error in handleMessage:', error);
    return { success: false, error: error.message };
  }
}

// Clear all cached data (analysis and H1B cache)
async function clearAllCache() {
  try {
    await chrome.storage.local.remove(['analysisCache', 'h1bCache']);
    console.log('ApplySafe: All caches cleared');
  } catch (error) {
    console.error('Error clearing cache:', error);
  }
}

// Analyze job posting with AI
async function analyzeJob(jobData, url, autoAnalysis = false) {
  try {
    // Check auth status and feature access
    const authStatus = await auth.getAuthStatus();
    const canAnalyze = await auth.canUseFeature('scan', url);
    
    if (!canAnalyze.allowed) {
      // User has exceeded limits
      if (authStatus.isAuthenticated) {
        // Signed in user - show server-synced limits
        showUpgradePrompt('limit_reached');
        return {
          success: false,
          error: 'limit_reached',
          message: `Daily scan limit reached (${canAnalyze.usage.scansToday}/10). Upgrade to Pro for unlimited scans!`,
          usage: canAnalyze.usage
        };
      } else {
        // Anonymous user - check local trial
        const localTrial = auth.getLocalTrialInfo();
        if (localTrial.isExpired) {
          showUpgradePrompt('trial_expired');
          return {
            success: false,
            error: 'trial_expired',
            message: 'Your 7-day trial has ended. Sign in with Google or upgrade to Pro!',
            trialInfo: localTrial
          };
        } else {
          showUpgradePrompt('limit_reached');
          return {
            success: false,
            error: 'limit_reached',
            message: `Daily scan limit reached (${localTrial.scansToday}/10). Sign in with Google or upgrade to Pro!`,
            trialInfo: localTrial
          };
        }
      }
    }
    
    // Always perform company verification (includes H1B check) - do this early
    console.log('ApplySafe: Starting company verification and H1B check...');
    const companyVerification = await verifyCompany(
      jobData.company,
      jobData.companyWebsite,
      jobData.title
    );
    console.log('ApplySafe: Company verification complete:', companyVerification);
    
    // Check cache first
    const cached = await getCachedAnalysis(url);
    if (cached && (Date.now() - cached.timestamp < CONFIG.CACHE_DURATION)) {
      console.log('ApplySafe: Using cached analysis');
      // Add fresh H1B data to cached result if available
      if (companyVerification && companyVerification.h1bSponsorship) {
        cached.companyVerification = cached.companyVerification || {};
        cached.companyVerification.h1bSponsorship = companyVerification.h1bSponsorship;
      }
      // Update stats even for cached results (counts as a scan view)
      await updateJobStats();
      return { success: true, result: cached };
    }
    
    // Rate limiting (only for auto-analysis, skip for user-initiated)
    if (autoAnalysis) {
      const now = Date.now();
      if (now - lastApiCall < CONFIG.RATE_LIMIT_DELAY) {
        await new Promise(resolve => setTimeout(resolve, CONFIG.RATE_LIMIT_DELAY));
      }
      lastApiCall = Date.now();
    }
    
    console.log('ApplySafe: Starting AI analysis via backend proxy...');
    
    // Log what we're sending to AI
    console.log('ApplySafe: Sending to backend:', {
      title: jobData.title,
      company: jobData.company,
      descriptionLength: jobData.description?.length || 0,
      salary: jobData.salary,
      location: jobData.location,
      emails: jobData.contactEmail,
      domain: jobData.companyDomain,
      companyVerification: companyVerification
    });
    
    // Call backend API with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), CONFIG.API_TIMEOUT);
    
    let response;
    let data;
    
    console.log('ApplySafe: Calling backend AI proxy...');
    const apiStartTime = Date.now();
    
    try {
      response = await fetch(CONFIG.API_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          jobData: {
            title: jobData.title,
            company: jobData.company,
            description: jobData.description,
            salary: jobData.salary,
            location: jobData.location,
            contactEmail: jobData.contactEmail,
            companyDomain: jobData.companyDomain,
            companyWebsite: jobData.companyWebsite
          }
        }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      
      const apiDuration = Date.now() - apiStartTime;
      console.log(`ApplySafe: Backend response received in ${apiDuration}ms`);
    
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Backend API Error:', errorData);
        
        // Fallback to heuristic analysis
        const heuristicResult = performHeuristicAnalysis(jobData);
        if (companyVerification) {
          heuristicResult.companyVerification = companyVerification;
        }
        await updateJobStats();
        return {
          success: true,
          result: heuristicResult
        };
      }
      
      data = await response.json();
      
      if (!data.success) {
        console.error('Backend returned error:', data.error);
        // Fallback to heuristic analysis
        const heuristicResult = performHeuristicAnalysis(jobData);
        if (companyVerification) {
          heuristicResult.companyVerification = companyVerification;
        }
        await updateJobStats();
        return {
          success: true,
          result: heuristicResult
        };
      }
    } catch (fetchError) {
      clearTimeout(timeoutId);
      if (fetchError.name === 'AbortError') {
        console.log('ApplySafe: Backend timeout, using heuristic analysis');
      } else {
        console.error('ApplySafe: Backend fetch error:', fetchError);
      }
      // Fallback to heuristic analysis
      const heuristicResult = performHeuristicAnalysis(jobData);
      if (companyVerification) {
        heuristicResult.companyVerification = companyVerification;
      }
      await updateJobStats();
      return {
        success: true,
        result: heuristicResult
      };
    }
    
    console.log('ApplySafe: Backend response received, processing...');
    
    // Use the analysis from backend
    const analysis = data.analysis;
    
    // Add verification info to analysis for display
    if (companyVerification) {
      analysis.companyVerification = companyVerification;
    }
    
    console.log('ApplySafe: Final analysis:', analysis);
    
    // Cache the result for future use
    await saveCachedAnalysis(url, analysis);
    
    // Save to database
    try {
      await saveJob(jobData, analysis);
      console.log('ApplySafe: Job saved to database');
    } catch (dbError) {
      console.error('ApplySafe: Database save failed:', dbError);
    }
    
    // Show notification for high-risk jobs
    if (analysis.riskScore > 60 && !autoAnalysis) {
      showNotification(analysis, jobData);
    }
    
    // Send warning to content script if high risk
    if (analysis.riskScore > 30) {
      try {
        const tabs = await chrome.tabs.query({ url: url });
        for (const tab of tabs) {
          chrome.tabs.sendMessage(tab.id, {
            action: 'showWarning',
            analysis: analysis
          }).catch(() => {});
        }
      } catch (e) {
        console.log('Could not send warning to content script');
      }
    }
    
    // Update stats
    await updateJobStats();
    
    return { success: true, result: analysis };
    
  } catch (error) {
    console.error('Analysis error:', error);
    
    // Fallback to heuristic analysis
    return {
      success: true,
      result: performHeuristicAnalysis(jobData)
    };
  }
}

// Update job scan stats
async function updateJobStats() {
  try {
    const result = await chrome.storage.local.get(['stats']);
    const stats = result.stats || { scamsBlocked: 0, jobsScanned: 0, reportsSubmitted: 0 };
    stats.jobsScanned = (stats.jobsScanned || 0) + 1;
    await chrome.storage.local.set({ stats });
    console.log('ApplySafe: Stats updated, jobs scanned:', stats.jobsScanned);
  } catch (error) {
    console.error('Error updating stats:', error);
  }
}

// Build analysis prompt for Claude
function buildAnalysisPrompt(jobData) {
  const verification = jobData.companyVerification;
  let verificationText = '';
  
  if (verification) {
    const h1bText = verification.h1bSponsorship 
      ? `\n- H1B Sponsorship: ${verification.h1bSponsorship.sponsors ? 'YES ✓' : 'Not Found'} ${verification.h1bSponsorship.note ? '(' + verification.h1bSponsorship.note + ')' : ''}`
      : '';
      
    verificationText = `
Company Verification:
- Has Company Website: ${verification.hasWebsite ? 'Yes' : 'No'}
- Website Accessible & Verified: ${verification.websiteAccessible ? 'Yes' : 'No'}
- Has Career Page: ${verification.hasCareerPage ? 'Yes' : 'No'}
- Job Found on Career Site: ${verification.jobFoundOnCareerSite ? 'YES ✓✓✓' : 'No'}
- Verified URL: ${verification.verifiedUrl || 'Not found'}
- Confidence Level: ${verification.confidence}${h1bText}
${verification.websiteAccessible ? '- VERIFIED: Company website exists and is accessible (STRONG positive indicator)' : ''}
${verification.hasCareerPage ? '- VERIFIED: Company has an active career/jobs page (VERY STRONG positive indicator)' : ''}
${verification.jobFoundOnCareerSite ? '- ✓✓✓ VERIFIED: This exact job posting was found on the company\'s official career site (MAXIMUM confidence - reduce risk by 25 points)' : ''}`;
  }
  
  return `You are an expert job scam detector. Analyze this job posting and provide a balanced risk assessment.

JOB POSTING DATA:
Title: ${jobData.title || 'Not provided'}
Company: ${jobData.company || 'Not provided'}
Location: ${jobData.location || 'Not provided'}
Salary: ${jobData.salary || 'Not provided'}
Description: ${(jobData.description || '').substring(0, 3000)}

Contact Emails Found: ${(jobData.contactEmail || []).join(', ') || 'None'}
Company Domain: ${jobData.companyDomain || 'Unknown'}
${verificationText}

CRITICAL SCAM INDICATORS (High Risk - Score 60+):
1. Requests for upfront payment, fees, or "investment"
2. Requests for bank account, SSN, or credit card information
3. Promises of unrealistic pay (e.g., $500/day for simple tasks)
4. Severe grammar/spelling errors throughout
5. Strong pressure tactics (urgent, act now, limited time)
6. MLM/pyramid scheme language (recruit others, downline, be your own boss)
7. Wire transfer or cryptocurrency payment mentions
8. No verifiable company information at all

MODERATE CONCERNS (Medium Risk - Score 30-60):
9. Somewhat vague job responsibilities
10. Personal email domains for a large established company
11. Work-from-home with very high hourly rates
12. Missing salary or location (common for legitimate postings too)

IMPORTANT CONSIDERATIONS:
- Missing salary/location is NORMAL for many legitimate job postings
- Recruiters and staffing agencies often use company emails, not the hiring company's domain
- Job boards aggregate postings, so contact info may not be on the posting itself
- Focus on ACTUAL red flags, not just missing optional information
- If company name is clearly stated and description is professional, baseline risk should be LOW (15-25)
- If company verification shows a website/career page link, this is a STRONG positive indicator (reduce risk by 10-20 points)
- If job posting was found on company's official career site, this is MAXIMUM confidence (reduce risk by 25 points, should score 5-15)
- Having a verified company website with career page should result in LOW risk scores (10-20) unless there are severe red flags
- H1B sponsorship history is a positive indicator showing the company is established and legitimate

RESPOND IN THIS EXACT JSON FORMAT:
{
  "riskScore": <number 0-100, where 0 is completely safe and 100 is definitely a scam>,
  "jobTitle": "<extracted job title>",
  "company": "<extracted company name>",
  "redFlags": ["<specific concern 1>", "<specific concern 2>", ...],
  "positiveIndicators": ["<positive sign 1>", "<positive sign 2>", ...],
  "explanation": "<2-3 sentence summary of your assessment>"
}

Be balanced and evidence-based. Only flag serious concerns. Most legitimate postings should score 10-30.`;
}

// Parse AI response into structured data
function parseAIResponse(responseText, jobData) {
  try {
    // Try to extract JSON from response
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        riskScore: Math.min(100, Math.max(0, parsed.riskScore || 50)),
        jobTitle: parsed.jobTitle || jobData.title || 'Unknown Position',
        company: parsed.company || jobData.company || 'Unknown Company',
        redFlags: Array.isArray(parsed.redFlags) ? parsed.redFlags : [],
        positiveIndicators: Array.isArray(parsed.positiveIndicators) ? parsed.positiveIndicators : [],
        explanation: parsed.explanation || 'Analysis complete.'
      };
    }
  } catch (error) {
    console.error('Error parsing AI response:', error);
  }
  
  // Fallback
  return performHeuristicAnalysis(jobData);
}

// Perform heuristic-based analysis (fallback when no API key)
function performHeuristicAnalysis(jobData) {
  const redFlags = [];
  const positiveIndicators = [];
  let riskScore = 20; // Base score
  
  const description = (jobData.description || '').toLowerCase();
  const title = (jobData.title || '').toLowerCase();
  const company = (jobData.company || '').toLowerCase();
  
  // Check for red flags
  
  // Payment requirements
  if (/upfront|payment|invest|fee|deposit|wire transfer|western union/i.test(description)) {
    redFlags.push('Mentions of upfront payments or fees');
    riskScore += 30;
  }
  
  // Unrealistic pay
  if (/\$\d{4,}.*(?:per|\/)\s*(?:week|day)|make.*\$\d{4,}.*(?:weekly|daily)/i.test(description)) {
    redFlags.push('Potentially unrealistic compensation claims');
    riskScore += 20;
  }
  
  // Urgency tactics
  if (/urgent|immediately|act now|limited.*positions?|don't miss|hurry/i.test(description)) {
    redFlags.push('Pressure tactics or urgency language detected');
    riskScore += 15;
  }
  
  // Personal email domains
  const emails = jobData.contactEmail || [];
  const personalDomains = emails.filter(e => /gmail|yahoo|hotmail|outlook|aol/i.test(e));
  if (personalDomains.length > 0) {
    redFlags.push('Contact uses personal email domain instead of company email');
    riskScore += 20;
  }
  
  // Work from home with high pay
  if (/work.*from.*home|remote|wfh/i.test(description) && 
      /\$\d{3,}.*(?:per|\/)\s*(?:hour|hr)/i.test(description)) {
    redFlags.push('Remote work with unusually high hourly rates');
    riskScore += 15;
  }
  
  // Personal info requests
  if (/bank.*account|ssn|social security|credit card|routing number/i.test(description)) {
    redFlags.push('Requests for sensitive personal or financial information');
    riskScore += 35;
  }
  
  // Vague description
  if (description.length < 200) {
    redFlags.push('Very short or vague job description');
    riskScore += 10;
  }
  
  // MLM/Pyramid indicators
  if (/mlm|network marketing|recruitment|downline|team building.*income|be your own boss/i.test(description)) {
    redFlags.push('Possible MLM or pyramid scheme indicators');
    riskScore += 25;
  }
  
  // Grammar issues (basic check)
  const grammarIssues = description.match(/\s{2,}|[A-Z]{3,}\s|!!!|\?\?/g);
  if (grammarIssues && grammarIssues.length > 3) {
    redFlags.push('Multiple grammar or formatting issues');
    riskScore += 10;
  }
  
  // Check for positive indicators
  
  // Clear company info
  if (company && company.length > 3 && !/unknown|confidential/i.test(company)) {
    positiveIndicators.push('Company name is clearly stated');
    riskScore -= 5;
  }
  
  // Company domain
  if (jobData.companyDomain && !/(gmail|yahoo|hotmail)/i.test(jobData.companyDomain)) {
    positiveIndicators.push('Company appears to have a dedicated website');
    riskScore -= 10;
  }
  
  // Detailed requirements
  if (/requirements?:|qualifications?:|experience:/i.test(description)) {
    positiveIndicators.push('Lists specific job requirements');
    riskScore -= 5;
  }
  
  // Benefits mentioned
  if (/benefits?:|401k|health insurance|pto|paid time off|dental|vision/i.test(description)) {
    positiveIndicators.push('Mentions standard employment benefits');
    riskScore -= 10;
  }
  
  // Professional posting site
  if (/linkedin|indeed|glassdoor/i.test(jobData.url || '')) {
    positiveIndicators.push('Posted on a major job platform');
    riskScore -= 5;
  }
  
  // Normalize score
  riskScore = Math.min(100, Math.max(0, riskScore));
  
  // Generate explanation
  let explanation = '';
  if (riskScore <= 30) {
    explanation = 'This job posting appears legitimate based on our analysis. However, always verify the company independently before sharing personal information.';
  } else if (riskScore <= 60) {
    explanation = 'We detected some concerning elements in this posting. Proceed with caution and research the company thoroughly before applying.';
  } else {
    explanation = 'This posting shows multiple red flags commonly associated with job scams. We strongly recommend avoiding this opportunity and reporting it.';
  }
  
  return {
    riskScore,
    jobTitle: jobData.title || 'Unknown Position',
    company: jobData.company || 'Unknown Company',
    redFlags,
    positiveIndicators,
    explanation
  };
}

// Report a scam
async function reportScam(data) {
  try {
    const result = await chrome.storage.local.get(['reports', 'stats']);
    const reports = result.reports || [];
    const stats = result.stats || { scamsBlocked: 0, jobsScanned: 0, reportsSubmitted: 0 };
    
    // Add report
    reports.push({
      ...data,
      id: Date.now().toString(36) + Math.random().toString(36).substr(2)
    });
    
    // Update stats
    stats.reportsSubmitted = (stats.reportsSubmitted || 0) + 1;
    
    await chrome.storage.local.set({ reports, stats });
    
    // In a production app, you would send this to a server
    console.log('Scam reported:', data);
    
    return { success: true };
  } catch (error) {
    console.error('Error reporting scam:', error);
    return { success: false, error: error.message };
  }
}

// Show notification
function showNotification(analysis, jobData) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: '⚠️ High Risk Job Detected',
    message: `${analysis.jobTitle} at ${analysis.company} has a risk score of ${analysis.riskScore}/100. Click to view details.`,
    priority: 2
  });
}

// Context menu click handler
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'analyzeJob') {
    // Send message to content script to analyze
    chrome.tabs.sendMessage(tab.id, { action: 'forceAnalyze' }).catch(() => {});
  }
});

// Alarm for periodic cache cleanup
chrome.alarms.create('cacheCleanup', { periodInMinutes: 60 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'cacheCleanup') {
    await cleanupCache();
  }
});

// Check H1B sponsorship using h1bdata.info web scraping
async function checkH1BSponsorship(companyName) {
  try {
    if (!companyName || companyName === 'Unknown' || companyName === 'Unknown Company') {
      console.log('H1B check skipped: No valid company name');
      return null;
    }
    
    // Clean company name for search - remove common suffixes
    let cleanName = companyName
      .replace(/,?\s*(Inc\.?|LLC|Ltd\.?|Corp\.?|Corporation|Company|Co\.|Limited|L\.?P\.?|PLC|GmbH|S\.?A\.?|N\.?V\.?)$/i, '')
      .replace(/\s+/g, ' ')
      .trim();
    
    console.log(`Checking H1B sponsorship for: "${cleanName}"`);
    
    // First, check against known major H-1B sponsors (instant lookup)
    const knownSponsors = getKnownH1BSponsors();
    const lowerName = cleanName.toLowerCase();
    
    for (const [company, data] of Object.entries(knownSponsors)) {
      if (lowerName.includes(company) || company.includes(lowerName)) {
        console.log(`✓ Found in known H1B sponsors list: ${company}`);
        return {
          sponsors: true,
          note: data.note,
          totalApplications: data.approx,
          employer: companyName,
          source: 'known-sponsors'
        };
      }
    }
    
    // Try h1bdata.info for companies not in the known list
    try {
      console.log('Checking h1bdata.info for:', cleanName);
      const response = await fetch(
        `https://h1bdata.info/index.php?em=${encodeURIComponent(cleanName)}&job=&city=&year=All+Years`,
        {
          method: 'GET',
          headers: {
            'Accept': 'text/html'
          }
        }
      );
      
      if (response.ok) {
        const html = await response.text();
        console.log('H1B response received, length:', html.length);
        
        // Parse the HTML to find record count - matches "X records was found" or "X records were found"
        const recordMatch = html.match(/(\d[\d,]*)\s+records?\s+(?:was|were)\s+found/i);
        
        // Also check for salary info which indicates records exist
        const salaryMatch = html.match(/Median Salary is \$([\d,]+)/i);
        
        if (recordMatch) {
          const countStr = recordMatch[1].replace(/,/g, '');
          const count = parseInt(countStr);
          
          if (count > 0) {
            console.log(`✓ Found H1B sponsorship via h1bdata.info: ${count} records`);
            return {
              sponsors: true,
              note: `Has sponsored ${count.toLocaleString()} H-1B visa${count > 1 ? 's' : ''} (verified)`,
              totalApplications: count,
              employer: companyName,
              source: 'h1bdata.info'
            };
          }
        }
        
        if (salaryMatch) {
          console.log('✓ Found H1B salary data via h1bdata.info');
          return {
            sponsors: true,
            note: 'Company has H-1B sponsorship records (verified)',
            employer: companyName,
            source: 'h1bdata.info'
          };
        }
        
        console.log('No H1B records found in h1bdata.info response');
      } else {
        console.log('h1bdata.info returned status:', response.status);
      }
    } catch (fetchError) {
      console.log('h1bdata.info fetch error:', fetchError.message);
    }
    
    console.log(`No H1B sponsorship records found for "${cleanName}"`);
    return {
      sponsors: false,
      note: 'No H-1B sponsorship records found in database'
    };
  } catch (error) {
    console.log('H1B check error:', error.message);
    return null;
  }
}

// Known major H-1B sponsors (top sponsors by volume)
function getKnownH1BSponsors() {
  return {
    'amazon': { approx: 50000, note: 'Top H-1B sponsor - ~50,000+ visas sponsored' },
    'google': { approx: 35000, note: 'Major H-1B sponsor - ~35,000+ visas sponsored' },
    'microsoft': { approx: 30000, note: 'Major H-1B sponsor - ~30,000+ visas sponsored' },
    'meta': { approx: 15000, note: 'Major H-1B sponsor - ~15,000+ visas sponsored' },
    'facebook': { approx: 15000, note: 'Major H-1B sponsor - ~15,000+ visas sponsored' },
    'apple': { approx: 12000, note: 'Major H-1B sponsor - ~12,000+ visas sponsored' },
    'intel': { approx: 10000, note: 'Major H-1B sponsor - ~10,000+ visas sponsored' },
    'ibm': { approx: 15000, note: 'Major H-1B sponsor - ~15,000+ visas sponsored' },
    'infosys': { approx: 40000, note: 'Top H-1B sponsor - ~40,000+ visas sponsored' },
    'tata consultancy': { approx: 35000, note: 'Top H-1B sponsor - ~35,000+ visas sponsored' },
    'cognizant': { approx: 30000, note: 'Major H-1B sponsor - ~30,000+ visas sponsored' },
    'accenture': { approx: 15000, note: 'Major H-1B sponsor - ~15,000+ visas sponsored' },
    'deloitte': { approx: 12000, note: 'Major H-1B sponsor - ~12,000+ visas sponsored' },
    'walmart': { approx: 5000, note: 'H-1B sponsor - ~5,000+ visas sponsored' },
    'uber': { approx: 5000, note: 'H-1B sponsor - ~5,000+ visas sponsored' },
    'salesforce': { approx: 5000, note: 'H-1B sponsor - ~5,000+ visas sponsored' },
    'oracle': { approx: 8000, note: 'Major H-1B sponsor - ~8,000+ visas sponsored' },
    'cisco': { approx: 8000, note: 'Major H-1B sponsor - ~8,000+ visas sponsored' },
    'qualcomm': { approx: 5000, note: 'H-1B sponsor - ~5,000+ visas sponsored' },
    'nvidia': { approx: 4000, note: 'H-1B sponsor - ~4,000+ visas sponsored' },
    'adobe': { approx: 3500, note: 'H-1B sponsor - ~3,500+ visas sponsored' },
    'linkedin': { approx: 3000, note: 'H-1B sponsor - ~3,000+ visas sponsored' },
    'netflix': { approx: 2000, note: 'H-1B sponsor - ~2,000+ visas sponsored' },
    'airbnb': { approx: 1500, note: 'H-1B sponsor - ~1,500+ visas sponsored' },
    'stripe': { approx: 1500, note: 'H-1B sponsor - ~1,500+ visas sponsored' },
    'twitter': { approx: 2000, note: 'H-1B sponsor - ~2,000+ visas sponsored' },
    'x corp': { approx: 2000, note: 'H-1B sponsor - ~2,000+ visas sponsored' },
    'jpmorgan': { approx: 8000, note: 'Major H-1B sponsor - ~8,000+ visas sponsored' },
    'jp morgan': { approx: 8000, note: 'Major H-1B sponsor - ~8,000+ visas sponsored' },
    'goldman sachs': { approx: 5000, note: 'H-1B sponsor - ~5,000+ visas sponsored' },
    'morgan stanley': { approx: 4000, note: 'H-1B sponsor - ~4,000+ visas sponsored' },
    'bank of america': { approx: 4000, note: 'H-1B sponsor - ~4,000+ visas sponsored' },
    'capital one': { approx: 3000, note: 'H-1B sponsor - ~3,000+ visas sponsored' },
    'disney': { approx: 2500, note: 'H-1B sponsor - ~2,500+ visas sponsored' },
    'walt disney': { approx: 2500, note: 'H-1B sponsor - ~2,500+ visas sponsored' },
    'bloomberg': { approx: 2500, note: 'H-1B sponsor - ~2,500+ visas sponsored' },
    'spotify': { approx: 1000, note: 'H-1B sponsor - ~1,000+ visas sponsored' },
    'snap': { approx: 1000, note: 'H-1B sponsor - ~1,000+ visas sponsored' },
    'snapchat': { approx: 1000, note: 'H-1B sponsor - ~1,000+ visas sponsored' },
    'lyft': { approx: 1000, note: 'H-1B sponsor - ~1,000+ visas sponsored' },
    'doordash': { approx: 800, note: 'H-1B sponsor - ~800+ visas sponsored' },
    'instacart': { approx: 500, note: 'H-1B sponsor - ~500+ visas sponsored' },
    'palantir': { approx: 1500, note: 'H-1B sponsor - ~1,500+ visas sponsored' },
    'databricks': { approx: 1000, note: 'H-1B sponsor - ~1,000+ visas sponsored' },
    'snowflake': { approx: 800, note: 'H-1B sponsor - ~800+ visas sponsored' },
    'twilio': { approx: 500, note: 'H-1B sponsor - ~500+ visas sponsored' },
    'dropbox': { approx: 800, note: 'H-1B sponsor - ~800+ visas sponsored' },
    'zoom': { approx: 600, note: 'H-1B sponsor - ~600+ visas sponsored' },
    'servicenow': { approx: 1500, note: 'H-1B sponsor - ~1,500+ visas sponsored' },
    'workday': { approx: 1200, note: 'H-1B sponsor - ~1,200+ visas sponsored' },
    'vmware': { approx: 3000, note: 'H-1B sponsor - ~3,000+ visas sponsored' },
    'hpe': { approx: 2000, note: 'H-1B sponsor - ~2,000+ visas sponsored' },
    'hewlett packard': { approx: 2000, note: 'H-1B sponsor - ~2,000+ visas sponsored' },
    'dell': { approx: 2500, note: 'H-1B sponsor - ~2,500+ visas sponsored' },
    'paypal': { approx: 2000, note: 'H-1B sponsor - ~2,000+ visas sponsored' },
    'visa inc': { approx: 1500, note: 'H-1B sponsor - ~1,500+ visas sponsored' },
    'mastercard': { approx: 1200, note: 'H-1B sponsor - ~1,200+ visas sponsored' },
    'american express': { approx: 1500, note: 'H-1B sponsor - ~1,500+ visas sponsored' },
    'intuit': { approx: 1500, note: 'H-1B sponsor - ~1,500+ visas sponsored' },
    'square': { approx: 800, note: 'H-1B sponsor - ~800+ visas sponsored' },
    'block': { approx: 800, note: 'H-1B sponsor - ~800+ visas sponsored' },
    'robinhood': { approx: 400, note: 'H-1B sponsor - ~400+ visas sponsored' },
    'coinbase': { approx: 500, note: 'H-1B sponsor - ~500+ visas sponsored' },
    'epic games': { approx: 600, note: 'H-1B sponsor - ~600+ visas sponsored' },
    'electronic arts': { approx: 800, note: 'H-1B sponsor - ~800+ visas sponsored' },
    'ea': { approx: 800, note: 'H-1B sponsor - ~800+ visas sponsored' },
    'activision': { approx: 500, note: 'H-1B sponsor - ~500+ visas sponsored' },
    'riot games': { approx: 400, note: 'H-1B sponsor - ~400+ visas sponsored' },
    'pinterest': { approx: 800, note: 'H-1B sponsor - ~800+ visas sponsored' },
    'reddit': { approx: 400, note: 'H-1B sponsor - ~400+ visas sponsored' },
    'atlassian': { approx: 1000, note: 'H-1B sponsor - ~1,000+ visas sponsored' },
    'github': { approx: 600, note: 'H-1B sponsor - ~600+ visas sponsored' },
    'gitlab': { approx: 300, note: 'H-1B sponsor - ~300+ visas sponsored' },
    'openai': { approx: 500, note: 'H-1B sponsor - ~500+ visas sponsored' },
    'anthropic': { approx: 200, note: 'H-1B sponsor - ~200+ visas sponsored' }
  };
}

// Get cached H1B data for a company
async function getCachedH1B(companyName) {
  try {
    const result = await chrome.storage.local.get(['h1bCache']);
    const cache = result.h1bCache || {};
    const normalizedName = companyName.toLowerCase().trim();
    const cached = cache[normalizedName];
    
    // Check if cache is still valid (7 days)
    if (cached && Date.now() - cached.timestamp < 7 * 24 * 60 * 60 * 1000) {
      return cached;
    }
    return null;
  } catch (error) {
    console.error('Error reading H1B cache:', error);
    return null;
  }
}

// Cache H1B data for a company
async function cacheCompanyH1B(companyName, h1bData) {
  try {
    const result = await chrome.storage.local.get(['h1bCache']);
    const cache = result.h1bCache || {};
    const normalizedName = companyName.toLowerCase().trim();
    
    cache[normalizedName] = {
      ...h1bData,
      h1bSponsors: h1bData.sponsors,
      timestamp: Date.now()
    };
    
    await chrome.storage.local.set({ h1bCache: cache });
    console.log('H1B data cached for:', companyName);
  } catch (error) {
    console.error('Error caching H1B data:', error);
  }
}

// Verify company legitimacy
async function verifyCompany(companyName, companyWebsite, jobTitle) {
  try {
    console.log(`verifyCompany called with: company="${companyName}", website="${companyWebsite}"`);
    
    // Create a simple verification object based on available data only
    const verification = {
      hasWebsite: false,
      hasCareerPage: false,
      websiteAccessible: false,
      verifiedUrl: null,
      jobFoundOnCareerSite: false,
      h1bSponsorship: null,
      confidence: 'unknown'
    };
    
    // If we have a company website link from the job posting
    if (companyWebsite) {
      verification.hasWebsite = true;
      verification.websiteUrl = companyWebsite;
      
      // Check if it's a career/jobs page
      if (/career|job|hiring|work-?with-?us|join-?us/i.test(companyWebsite)) {
        verification.hasCareerPage = true;
        verification.confidence = 'high';
        verification.verifiedUrl = companyWebsite;
      } else {
        verification.confidence = 'medium';
      }
      
      // Check for legitimate company domains (not free email providers)
      if (!/gmail|yahoo|hotmail|outlook|aol|protonmail|mail\.com/i.test(companyWebsite)) {
        verification.websiteAccessible = true; // Assume accessible if it's a real domain
      }
    }
    
    // Check H1B sponsorship using the new module (with caching)
    // Validate company name is actually usable (not empty, not "Unknown", not too short)
    const isValidCompany = companyName && 
                           companyName.length >= 2 && 
                           companyName.toLowerCase() !== 'unknown' && 
                           companyName.toLowerCase() !== 'unknown company' &&
                           companyName.toLowerCase() !== 'not provided';
    
    if (isValidCompany) {
      console.log(`Starting H1B check for: ${companyName}`);
      
      // Use the new H1B module for comprehensive lookup
      verification.h1bSponsorship = await self.h1bModule.checkH1BSponsorship(companyName);
      console.log('H1B check result:', verification.h1bSponsorship);
    } else {
      console.log(`Skipping H1B check - invalid company name: "${companyName}"`);
    }
    
    return verification;
  } catch (error) {
    console.log('Company verification error:', error);
    return null;
  }
}

// Get cached analysis
async function getCachedAnalysis(url) {
  try {
    const result = await chrome.storage.local.get(['analysisCache']);
    const cache = result.analysisCache || {};
    return cache[url];
  } catch (error) {
    return null;
  }
}

// Save analysis to cache
async function saveCachedAnalysis(url, analysis) {
  try {
    const result = await chrome.storage.local.get(['analysisCache']);
    const cache = result.analysisCache || {};
    cache[url] = { ...analysis, timestamp: Date.now() };
    await chrome.storage.local.set({ analysisCache: cache });
  } catch (error) {
    console.error('Cache save error:', error);
  }
}

async function cleanupCache() {
  try {
    const result = await chrome.storage.local.get(['analysisCache']);
    const cache = result.analysisCache || {};
    const now = Date.now();
    
    // Remove entries older than cache duration
    for (const [url, data] of Object.entries(cache)) {
      if (now - data.timestamp > CONFIG.CACHE_DURATION) {
        delete cache[url];
      }
    }
    
    await chrome.storage.local.set({ analysisCache: cache });
  } catch (error) {
    console.error('Cache cleanup error:', error);
  }
}

console.log('ApplySafe background service worker loaded');
